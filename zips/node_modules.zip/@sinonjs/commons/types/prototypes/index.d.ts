export declare const array: any;
declare const _function: any;
export { _function as function };
export declare const map: any;
export declare const object: any;
export declare const set: any;
export declare const string: any;
